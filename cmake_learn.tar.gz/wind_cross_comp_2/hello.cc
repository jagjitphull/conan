
#include <iostream>

int main() {
    std::cout << "Hello, Windows!" << std::endl;
    return 0;
}

