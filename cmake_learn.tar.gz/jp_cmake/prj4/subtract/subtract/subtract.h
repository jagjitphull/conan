#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int subtract_i(int l, int r)
{
    return l - r;
}

#ifdef __cplusplus
}
#endif
