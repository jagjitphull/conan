//#include "subtract/subtract.h"

int subtract_i(int l, int r)
{
    return l - r;
}
