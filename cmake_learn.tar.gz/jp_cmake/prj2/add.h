#pragma once
#include "calc_status.h"

namespace Add
{

int add(int l, int r, calc_status& cs) noexcept;

} // namespace Add
