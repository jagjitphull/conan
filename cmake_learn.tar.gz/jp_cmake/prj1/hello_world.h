#pragma once
void say_hello();
