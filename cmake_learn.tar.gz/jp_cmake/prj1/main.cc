#include "hello_world.h"

int main()
{
    say_hello();
}
