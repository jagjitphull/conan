#include "hello_world.h"
#include <iostream>

void say_hello()
{
    std::cout << "Hello, World!\n";
}
