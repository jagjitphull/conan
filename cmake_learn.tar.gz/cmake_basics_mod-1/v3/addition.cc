float addition(float num0, float num2)
{
    return num0 + num2;
}